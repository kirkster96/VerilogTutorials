#!/bin/bash
bash ./overlay.sh
sleep 5 

echo "Message : Application Start"
python3.7 -u ./main.py