# Sensor Aggregation Reference Design

There are FPGA design to make an extended card enabled and host applications to use Azure works on HPS.  
The target board is [FPGA Cloud Connectivity Kit][LINK_FCCK] bundles DE10-Nano Kit and RFS Daughter Card.  
Please read below documents to use it.

Quick Started : <https://github.com/terasic/InnovateFPGA2021>  
Developers Guide Link : [Here](top.md)

[LINK_FCCK]: https://www.terasic.com.tw/cgi-bin/page/archive.pl?Language=English&CategoryNo=162&No=993
