# code-samples directory

This directory contains source code examples that are designed to run on the Terasic DE10-Nano development kit by Terasic Technologies Inc.  Please see the README files in each example directory for more details.

